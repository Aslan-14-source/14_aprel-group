package az.developia.spring_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
